/* SoundDrop v7 — Service Worker  (cache v4) */
const VER = 'sd7-v4';
const SHELL = ['/', '/index.html', '/manifest.json', '/icon-192.png'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(VER).then(c => c.addAll(SHELL)));
  self.skipWaiting();
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks =>
    Promise.all(ks.filter(k => k !== VER).map(k => caches.delete(k)))));
  self.clients.claim();
});
self.addEventListener('fetch', e => {
  const u = new URL(e.request.url);
  if (u.pathname.startsWith('/api/') || u.pathname.startsWith('/files/') || u.pathname.startsWith('/socket.io/')) {
    e.respondWith(fetch(e.request).catch(() => new Response('{"error":"offline"}',{status:503,headers:{'Content-Type':'application/json'}})));
    return;
  }
  e.respondWith(caches.match(e.request).then(c => {
    const fresh = fetch(e.request).then(r => {
      if (r.ok) caches.open(VER).then(cache => cache.put(e.request, r.clone()));
      return r;
    }).catch(() => null);
    return c || fresh;
  }));
});
self.addEventListener('push', e => {
  const d = e.data?.json() || { title: 'SoundDrop', body: 'Download complete' };
  e.waitUntil(self.registration.showNotification(d.title, {
    body: d.body, icon: '/icon-192.png', badge: '/icon-192.png',
    data: d.url || '/',
    vibrate: [200, 100, 200],
    actions: [{ action: 'open', title: 'Open' }]
  }));
});
self.addEventListener('notificationclick', e => {
  e.notification.close();
  e.waitUntil(clients.openWindow(e.notification.data || '/'));
});
