╔══════════════════════════════════════╗
║   DyrakArmy Mobile — iOS / Android   ║
║   Progressive Web App (PWA)          ║
╚══════════════════════════════════════╝

ИНСТАЛАЦИЯ НА iOS (Safari):
  1. Отвори https://dyrakarmy.online в Safari
  2. Натисни Share (⎙) → "Add to Home Screen" → Add
  3. Иконата се появява на началния екран — работи като нативно приложение!

ИНСТАЛАЦИЯ НА Android (Chrome):
  1. Отвори https://dyrakarmy.online в Chrome
  2. Ще видиш банер "Add to Home Screen" или:
     Menu (⋮) → "Install app" / "Add to Home Screen"
  3. Приложението се инсталира с иконата на DyrakArmy

ХАРАКТЕРИСТИКИ:
  ✅ Работи офлайн (Service Worker кеш)
  ✅ Push известия при готово сваляне
  ✅ Синхронизация в реално между устройства
  ✅ Тъмна тема, responsive дизайн
  ✅ Bottom navigation за мобилни
  ✅ Инсталируемо като нативно приложение

ЛОКАЛЕН ТЕСТ (без интернет):
  Просто отвори index.html в браузъра
