#!/bin/bash
# DyrakArmy Telegram Bot Launcher
echo "🤖 Стартиране на @dyrakarmy_bot ..."

# Install deps
pip3 install -r requirements.txt --quiet

# Load env
if [ -f .env ]; then
  export $(grep -v '^#' .env | xargs)
fi

# Start bot
python3 dyrakarmy_bot.py
