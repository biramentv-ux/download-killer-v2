"""
DyrakArmy_BOT — @dyrakarmy_bot
Telegram музикален бот на български — пълна функционалност.
Моделиран по Spotify Music Downloader, но с БГ интерфейс.
"""

import os, asyncio, logging, json, re, aiohttp
from pathlib import Path
from typing import Optional

from telegram import (
    Update, InlineKeyboardButton, InlineKeyboardMarkup,
    Audio, InputFile, BotCommand,
)
from telegram.ext import (
    Application, CommandHandler, MessageHandler,
    CallbackQueryHandler, filters, ContextTypes,
)
from telegram.constants import ParseMode, ChatAction

# ── Config ────────────────────────────────────────────────────────────────────
BOT_TOKEN   = os.getenv("TELEGRAM_BOT_TOKEN", "8623007915:AAEJ4IEw4OKwUuGS5_0yaZTZUn4K6qBjXt4")
API_URL     = os.getenv("DYRAKARMY_API_URL",  "https://dyrakarmy.online")
API_KEY     = os.getenv("DYRAKARMY_API_KEY",  "")
DATA_DIR    = Path(os.getenv("DATA_DIR", "/tmp/dyrakarmy"))
DATA_DIR.mkdir(parents=True, exist_ok=True)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("dyrakarmy_bot")

# ── User state (stored in JSON per user) ─────────────────────────────────────

DEFAULT_PREFS = {
    "quality":          "320",
    "format":           "mp3",
    "source":           "all",
    "unsupported_url":  True,
    "search_query":     True,
    "receive_broadcast":True,
    "receive_done_msg": True,
    "respond_http":     True,
    "release_radar":    False,   # premium feature
    "notifications":    True,
}

def load_prefs(uid: int) -> dict:
    f = DATA_DIR / f"{uid}.json"
    try:
        return {**DEFAULT_PREFS, **json.loads(f.read_text())} if f.exists() else dict(DEFAULT_PREFS)
    except Exception:
        return dict(DEFAULT_PREFS)

def save_prefs(uid: int, prefs: dict):
    (DATA_DIR / f"{uid}.json").write_text(json.dumps(prefs))

def pref_set(uid: int, key: str, val):
    p = load_prefs(uid); p[key] = val; save_prefs(uid, p)

# ── Quality labels ─────────────────────────────────────────────────────────────

QUALITY_LABELS = {
    "flac":     "🎵 FLAC — Lossless",
    "wav":      "🌊 WAV — Lossless",
    "mp3_320":  "🎧 MP3 (320kbps)",
    "mp3_128":  "🎧 MP3 (128kbps)",
    "ogg_320":  "🔊 OGG (320kbps)",
    "ogg_128":  "🔊 OGG (128kbps)",
    "opus_best":"⚡ OPUS — Най-добро",
    "m4a_best": "🍎 M4A — Най-добро",
}

QUALITY_MAP = {
    "flac":     ("flac", "lossless"),
    "wav":      ("wav",  "lossless"),
    "mp3_320":  ("mp3",  "320"),
    "mp3_128":  ("mp3",  "128"),
    "ogg_320":  ("ogg",  "320"),
    "ogg_128":  ("ogg",  "128"),
    "opus_best":("opus", "best"),
    "m4a_best": ("m4a",  "best"),
}

SOURCE_LABELS = {
    "all":        "🌐 Всички",
    "youtube":    "🔴 YouTube",
    "spotify":    "🟢 Spotify",
    "soundcloud": "🟠 SoundCloud",
    "deezer":     "🩵 Deezer",
    "apple":      "🍎 Apple Music",
    "amazon":     "📦 Amazon Music",
    "tidal":      "🐳 Tidal",
    "qobuz":      "🎼 Qobuz",
    "beatport":   "🎛️ Beatport",
}

# ── Keyboards ──────────────────────────────────────────────────────────────────

def kb_main_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("⭐ Промени качество", callback_data="menu:quality")],
        [InlineKeyboardButton("🔧 Персонализирай",   callback_data="menu:customize")],
        [InlineKeyboardButton("🆘 Помощ",             callback_data="menu:help")],
    ])

def kb_quality(current_fmt: str, current_qual: str) -> InlineKeyboardMarkup:
    def check(qid: str) -> str:
        fmt, qual = QUALITY_MAP[qid]
        return " ✅" if fmt == current_fmt and qual == current_qual else ""

    rows = [
        [InlineKeyboardButton(QUALITY_LABELS["flac"]    + check("flac"),     callback_data="qual:flac"),
         InlineKeyboardButton(QUALITY_LABELS["wav"]     + check("wav"),      callback_data="qual:wav")],
        [InlineKeyboardButton(QUALITY_LABELS["mp3_320"] + check("mp3_320"), callback_data="qual:mp3_320"),
         InlineKeyboardButton(QUALITY_LABELS["mp3_128"] + check("mp3_128"), callback_data="qual:mp3_128")],
        [InlineKeyboardButton(QUALITY_LABELS["ogg_320"] + check("ogg_320"), callback_data="qual:ogg_320"),
         InlineKeyboardButton(QUALITY_LABELS["ogg_128"] + check("ogg_128"), callback_data="qual:ogg_128")],
        [InlineKeyboardButton(QUALITY_LABELS["opus_best"]+ check("opus_best"),callback_data="qual:opus_best"),
         InlineKeyboardButton(QUALITY_LABELS["m4a_best"] + check("m4a_best"), callback_data="qual:m4a_best")],
        [InlineKeyboardButton("◀️ Назад", callback_data="menu:back")],
    ]
    return InlineKeyboardMarkup(rows)

def kb_source(current: str) -> InlineKeyboardMarkup:
    def mark(s): return f"{SOURCE_LABELS[s]}" + (" ✅" if s == current else "")
    rows = [
        [InlineKeyboardButton(mark("all"),        callback_data="src:all")],
        [InlineKeyboardButton(mark("youtube"),    callback_data="src:youtube"),
         InlineKeyboardButton(mark("spotify"),    callback_data="src:spotify")],
        [InlineKeyboardButton(mark("soundcloud"), callback_data="src:soundcloud"),
         InlineKeyboardButton(mark("deezer"),     callback_data="src:deezer")],
        [InlineKeyboardButton(mark("apple"),      callback_data="src:apple"),
         InlineKeyboardButton(mark("amazon"),     callback_data="src:amazon")],
        [InlineKeyboardButton(mark("tidal"),      callback_data="src:tidal"),
         InlineKeyboardButton(mark("qobuz"),      callback_data="src:qobuz")],
        [InlineKeyboardButton(mark("beatport"),   callback_data="src:beatport")],
        [InlineKeyboardButton("◀️ Назад", callback_data="menu:customize")],
    ]
    return InlineKeyboardMarkup(rows)

def kb_customize(prefs: dict) -> InlineKeyboardMarkup:
    def tog(key): return "✅" if prefs.get(key) else "❌"
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(f"НЕПОДДЪРЖАН URL {tog('unsupported_url')}",  callback_data="tog:unsupported_url"),
         InlineKeyboardButton(f"ТЪРСЕНЕ {tog('search_query')}",             callback_data="tog:search_query")],
        [InlineKeyboardButton(f"ПОЛУЧАВАЙ ИЗЛЪЧВАНИЯ {tog('receive_broadcast')}",   callback_data="tog:receive_broadcast")],
        [InlineKeyboardButton(f"СЪОБЩЕНИЕ ПРИ ГОТОВНОСТ {tog('receive_done_msg')}", callback_data="tog:receive_done_msg")],
        [InlineKeyboardButton(f"ОТГОВОР НА HTTP ЛИНКОВЕ {tog('respond_http')}",      callback_data="tog:respond_http")],
        [InlineKeyboardButton("🎵 Избери изтоник",           callback_data="menu:source")],
        [InlineKeyboardButton("🔔 Радар за нови издания 🌟",  callback_data="menu:radar")],
        [InlineKeyboardButton("🆘 Помощ 🧯",                  callback_data="menu:help"),
         InlineKeyboardButton("◀️ Назад",                     callback_data="menu:back")],
    ])

def kb_settings_categories() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("⚙️ Общи",                      callback_data="menu:back")],
        [InlineKeyboardButton("🎵 Качество и информация",      callback_data="menu:quality")],
        [InlineKeyboardButton("📥 Сваляния",                   callback_data="menu:customize")],
        [InlineKeyboardButton("📝 Надписи и шаблони",          callback_data="menu:captions")],
    ])

def kb_results(results: list) -> InlineKeyboardMarkup:
    rows = []
    for i, r in enumerate(results[:8]):
        title   = r.get("title", "")[:35]
        artist  = r.get("artist", "")[:20]
        src_ico = {"youtube":"🔴","spotify":"🟢","soundcloud":"🟠","deezer":"🩵","apple":"🍎"}.get(r.get("source",""), "🎵")
        label   = f"{src_ico} {artist} — {title}"
        rows.append([InlineKeyboardButton(label, callback_data=f"dl:{i}")])
    return InlineKeyboardMarkup(rows)

def kb_download_format(track_idx: int, prefs: dict) -> InlineKeyboardMarkup:
    fmt, qual = prefs["format"], prefs["quality"]
    quality_id = next((k for k,(f,q) in QUALITY_MAP.items() if f==fmt and q==qual), "mp3_320")
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(f"✅ {QUALITY_LABELS.get(quality_id,'MP3 320')} — Свали", callback_data=f"go:{track_idx}:{quality_id}")],
        [InlineKeyboardButton("⭐ Промени качество", callback_data=f"chq:{track_idx}")],
        [InlineKeyboardButton("❌ Отказ", callback_data="cancel")],
    ])

# ── API helpers ──────────────────────────────────────────────────────────────

async def api_search(query: str, source: str = "all", limit: int = 8) -> list:
    try:
        async with aiohttp.ClientSession() as sess:
            async with sess.post(
                f"{API_URL}/api/search",
                json={"query": query, "source": source if source != "all" else None, "limit": limit},
                headers={"X-API-Key": API_KEY},
                timeout=aiohttp.ClientTimeout(total=15),
            ) as r:
                if r.ok:
                    return (await r.json()).get("results", [])
    except Exception as e:
        log.error("Search error: %s", e)
    return []

async def api_download(url: str, fmt: str, qual: str) -> Optional[dict]:
    try:
        async with aiohttp.ClientSession() as sess:
            async with sess.post(
                f"{API_URL}/api/download",
                json={"url": url, "format": fmt, "quality": qual},
                headers={"X-API-Key": API_KEY},
                timeout=aiohttp.ClientTimeout(total=10),
            ) as r:
                if r.ok:
                    return await r.json()
    except Exception as e:
        log.error("Download error: %s", e)
    return None

async def api_job_status(job_id: str, max_wait: int = 120) -> Optional[dict]:
    """Poll job status until done or timeout."""
    async with aiohttp.ClientSession() as sess:
        for _ in range(max_wait // 3):
            await asyncio.sleep(3)
            try:
                async with sess.get(
                    f"{API_URL}/api/job/{job_id}",
                    headers={"X-API-Key": API_KEY},
                    timeout=aiohttp.ClientTimeout(total=8),
                ) as r:
                    if r.ok:
                        j = (await r.json()).get("job", {})
                        if j.get("status") in ("done", "failed"):
                            return j
            except Exception:
                pass
    return None

async def api_get_file(result_url: str) -> Optional[bytes]:
    try:
        url = result_url if result_url.startswith("http") else f"{API_URL}{result_url}"
        async with aiohttp.ClientSession() as sess:
            async with sess.get(url, timeout=aiohttp.ClientTimeout(total=60)) as r:
                if r.ok:
                    return await r.read()
    except Exception as e:
        log.error("File fetch error: %s", e)
    return None

# ── Session state (per chat, in-memory) ───────────────────────────────────────

_session: dict = {}  # chat_id → {results: list, track: dict, ...}

def sess(chat_id: int) -> dict:
    if chat_id not in _session:
        _session[chat_id] = {}
    return _session[chat_id]

# ── Handlers ──────────────────────────────────────────────────────────────────

async def cmd_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    prefs = load_prefs(update.effective_user.id)
    fmt, qual = QUALITY_MAP.get(
        next((k for k,(f,q) in QUALITY_MAP.items() if f==prefs["format"] and q==prefs["quality"]), "mp3_320"),
        ("mp3","320")
    )
    quality_name = next((v for k,v in QUALITY_LABELS.items() if QUALITY_MAP[k]==( prefs["format"], prefs["quality"])), "MP3 320kbps")

    await update.message.reply_text(
        f"👋 Добре дошъл в *DyrakArmy Bot*!\n\n"
        f"🎵 Изпрати ми линк или заявка за търсене.\n"
        f"📥 Поддържани: YouTube, Spotify, SoundCloud, Deezer...\n\n"
        f"⚙️ Текущо качество: *{quality_name}*\n\n"
        f"Използвай /settings за настройки.",
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton("⚙️ Настройки", callback_data="menu:settings"),
            InlineKeyboardButton("🆘 Помощ",     callback_data="menu:help"),
        ]])
    )

async def cmd_settings(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "⚙️ *Настройки*\n\nИзбери категория за конфигуриране.",
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=kb_settings_categories(),
    )

async def cmd_help(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🆘 *Помощ — DyrakArmy Bot*\n\n"
        "▶️ *Как да използваш:*\n"
        "1. Изпрати линк от YouTube/Spotify/SoundCloud\n"
        "2. Или напиши: `Изпълнител — Заглавие`\n"
        "3. Избери качество → Свали\n\n"
        "📋 *Команди:*\n"
        "/start — Начало\n"
        "/settings — Настройки\n"
        "/quality — Смени качество\n"
        "/source — Избери изтоник\n"
        "/help — Тази помощ\n\n"
        "🎵 *Поддържани:* YouTube · Spotify · SoundCloud · Deezer · Apple Music\n\n"
        "🌟 *Качества:* FLAC · WAV · MP3 320/128 · OGG · OPUS · M4A",
        parse_mode=ParseMode.MARKDOWN,
    )

async def cmd_quality(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    prefs = load_prefs(update.effective_user.id)
    await update.message.reply_text(
        f"🎵 *Избери качество на сваляне*\n"
        f"Текущо: *{prefs['format'].upper()} {prefs['quality']}*",
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=kb_quality(prefs["format"], prefs["quality"]),
    )

async def cmd_source(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    prefs = load_prefs(update.effective_user.id)
    await update.message.reply_text(
        "🌐 *Избери изтоник за търсене:*",
        parse_mode=ParseMode.MARKDOWN,
        reply_markup=kb_source(prefs["source"]),
    )

async def on_message(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not update.message or not update.message.text:
        return
    text  = update.message.text.strip()
    uid   = update.effective_user.id
    prefs = load_prefs(uid)

    # URL detection
    is_url = bool(re.match(r"https?://", text))

    if is_url and not prefs.get("unsupported_url", True):
        return  # user disabled URL handling

    if not is_url and not prefs.get("search_query", True):
        return  # user disabled search

    await update.message.chat.send_action(ChatAction.TYPING)

    if is_url:
        # Direct URL — try to get info and offer download
        sess_data = sess(update.effective_user.id)
        sess_data["pending_url"] = text
        fmt, qual = prefs["format"], prefs["quality"]
        quality_id = next((k for k,(f,q) in QUALITY_MAP.items() if f==fmt and q==qual), "mp3_320")
        await update.message.reply_text(
            f"🔗 Открит линк!\n\n`{text[:60]}{'…' if len(text)>60 else ''}`",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton(f"✅ {QUALITY_LABELS.get(quality_id,'Свали')} — Свали", callback_data="go_url")],
                [InlineKeyboardButton("⭐ Промени качество", callback_data="chq_url")],
                [InlineKeyboardButton("❌ Отказ", callback_data="cancel")],
            ]),
        )
    else:
        # Text search
        results = await api_search(text, prefs.get("source", "all"))
        if not results:
            await update.message.reply_text(
                f"❌ Няма резултати за: *{text}*\n\nОпитай с различна заявка.",
                parse_mode=ParseMode.MARKDOWN,
            )
            return
        sess(uid)["results"] = results
        await update.message.reply_text(
            f"🔍 Намерени *{len(results)}* резултата за: _{text}_\n\nИзбери:",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=kb_results(results),
        )

async def on_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q   = update.callback_query
    uid = q.from_user.id
    await q.answer()
    data  = q.data
    prefs = load_prefs(uid)

    # ── Menu navigation ────────────────────────────────────────────────────────
    if data == "menu:settings":
        await q.edit_message_text(
            "⚙️ *Настройки*\n\nИзбери категория.",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=kb_settings_categories(),
        )

    elif data == "menu:back":
        await q.edit_message_text(
            "⚙️ *Настройки*\n\nМоля персонализирай настройките.",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=kb_main_menu(),
        )

    elif data == "menu:quality":
        await q.edit_message_text(
            f"🎵 *Избери качество на сваляне*\n"
            f"Текущо: *{prefs['format'].upper()} {prefs['quality']}* 🎧",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=kb_quality(prefs["format"], prefs["quality"]),
        )

    elif data == "menu:customize":
        await q.edit_message_text(
            "🔧 *Персонализирай настройките:*",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=kb_customize(prefs),
        )

    elif data == "menu:source":
        await q.edit_message_text(
            "🌐 *Избери изтоник за търсене:*",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=kb_source(prefs.get("source","all")),
        )

    elif data == "menu:help":
        await q.edit_message_text(
            "🆘 *Помощ — DyrakArmy Bot*\n\n"
            "Изпрати линк или заявка за търсене.\n"
            "Поддържани: YouTube · Spotify · SoundCloud · Deezer\n\n"
            "Команди: /settings /quality /source /help",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Назад", callback_data="menu:back")]]),
        )

    elif data == "menu:radar":
        await q.edit_message_text(
            "🔔 *Радар за нови издания*\n\n"
            "Следи артисти и получавай известия при нови албуми.\n\n"
            "🌟 Тази функция е налична за _премиум_ потребители.\n"
            "Свържи се с @dyrakarmy_bot за информация.",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Назад", callback_data="menu:customize")]]),
        )

    elif data == "menu:captions":
        await q.edit_message_text(
            "📝 *Надписи и шаблони*\n\n"
            "Шаблон при готовност:\n"
            "`✅ {title} — {artist} | {format} {quality}`\n\n"
            "Настройките за надписи скоро ще бъдат добавени.",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("◀️ Назад", callback_data="menu:back")]]),
        )

    # ── Quality selection ──────────────────────────────────────────────────────
    elif data.startswith("qual:"):
        qid = data.split(":")[1]
        if qid in QUALITY_MAP:
            fmt, qual = QUALITY_MAP[qid]
            pref_set(uid, "format", fmt)
            pref_set(uid, "quality", qual)
            await q.answer(f"✅ Качество: {QUALITY_LABELS[qid]}", show_alert=True)
            prefs = load_prefs(uid)
            await q.edit_message_reply_markup(kb_quality(fmt, qual))

    # ── Source selection ───────────────────────────────────────────────────────
    elif data.startswith("src:"):
        src = data.split(":")[1]
        pref_set(uid, "source", src)
        prefs = load_prefs(uid)
        await q.answer(f"✅ Изтоник: {SOURCE_LABELS.get(src, src)}", show_alert=True)
        await q.edit_message_reply_markup(kb_source(src))

    # ── Toggle options ─────────────────────────────────────────────────────────
    elif data.startswith("tog:"):
        key = data.split(":")[1]
        prefs[key] = not prefs.get(key, True)
        save_prefs(uid, prefs)
        await q.edit_message_reply_markup(kb_customize(prefs))

    # ── Search result picked ───────────────────────────────────────────────────
    elif data.startswith("dl:"):
        idx     = int(data.split(":")[1])
        results = sess(uid).get("results", [])
        if idx >= len(results):
            await q.answer("❌ Невалиден избор", show_alert=True)
            return
        track = results[idx]
        sess(uid)["track"] = track
        duration = track.get("duration", 0)
        dur_str  = f"{duration//60}:{duration%60:02d}" if duration else "—"
        quality_id = next((k for k,(f,q) in QUALITY_MAP.items() if f==prefs["format"] and q==prefs["quality"]), "mp3_320")
        await q.edit_message_text(
            f"🎵 *{track.get('title','—')}*\n"
            f"👤 {track.get('artist','—')}\n"
            f"💿 {track.get('album','—')}\n"
            f"⏱ {dur_str}\n"
            f"🌐 {SOURCE_LABELS.get(track.get('source',''), '—')}\n\n"
            f"📥 Качество: *{QUALITY_LABELS.get(quality_id,'MP3 320')}*",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=kb_download_format(idx, prefs),
        )

    # ── Change quality for specific track ─────────────────────────────────────
    elif data.startswith("chq:"):
        idx = int(data.split(":")[1])
        sess(uid)["pending_dl_idx"] = idx
        await q.edit_message_text(
            "⭐ Избери качество за това сваляне:",
            reply_markup=kb_quality(prefs["format"], prefs["quality"]),
        )

    elif data == "chq_url":
        await q.edit_message_text(
            "⭐ Избери качество:",
            reply_markup=kb_quality(prefs["format"], prefs["quality"]),
        )

    # ── Execute download ───────────────────────────────────────────────────────
    elif data.startswith("go:") or data == "go_url":
        if data == "go_url":
            url = sess(uid).get("pending_url")
            quality_id = next((k for k,(f,q) in QUALITY_MAP.items() if f==prefs["format"] and q==prefs["quality"]), "mp3_320")
            track = {"url": url, "title": "Track", "artist": ""}
        else:
            parts = data.split(":")
            idx   = int(parts[1])
            quality_id = parts[2]
            results    = sess(uid).get("results", [])
            track      = results[idx] if idx < len(results) else sess(uid).get("track")
            if not track:
                await q.answer("❌ Невалиден избор", show_alert=True)
                return

        fmt, qual = QUALITY_MAP.get(quality_id, ("mp3", "320"))
        url       = track.get("url", "")

        status_msg = await q.edit_message_text(
            f"⏳ *Сваля се...*\n\n"
            f"🎵 {track.get('title','—')}\n"
            f"👤 {track.get('artist','—')}\n"
            f"📥 {fmt.upper()} · {qual}\n\n"
            f"_Моля изчакай..._",
            parse_mode=ParseMode.MARKDOWN,
        )

        job = await api_download(url, fmt, qual)
        if not job:
            await status_msg.edit_text("❌ Грешка при свалянето. Опитай отново.")
            return

        job_id = job.get("jobId")
        result = await api_job_status(job_id)

        if not result or result.get("status") != "done":
            err = result.get("error", "Неизвестна грешка") if result else "Timeout"
            await status_msg.edit_text(f"❌ *Неуспешно:* {err}", parse_mode=ParseMode.MARKDOWN)
            return

        result_url = result.get("result_url")
        file_bytes = await api_get_file(result_url) if result_url else None

        if file_bytes:
            file_size_mb = len(file_bytes) / 1_048_576
            caption = (
                f"🎵 *{result.get('title', track.get('title','—'))}*\n"
                f"👤 {result.get('artist', track.get('artist','—'))}\n"
                f"📥 {fmt.upper()} · {qual} · {file_size_mb:.1f} MB\n\n"
                f"🔔 Заредено от [DyrakArmy](https://dyrakarmy.online)"
            )
            filename = f"{result.get('title','track')}.{fmt}".replace(" ", "_")[:64]
            await q.message.chat.send_action(ChatAction.UPLOAD_AUDIO)
            await q.message.chat.send_audio(
                audio=InputFile(file_bytes, filename=filename),
                caption=caption,
                parse_mode=ParseMode.MARKDOWN,
                title=result.get("title", ""),
                performer=result.get("artist", ""),
                duration=result.get("duration"),
            )
            await status_msg.edit_text(
                f"🔔 *Готово!* 🔔\n"
                f"_{result.get('title','')}_ беше изпратен.\n"
                f"Ако харесваш бота, сподели го! 🙏",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🌐 Отвори сайта", url="https://dyrakarmy.online")],
                    [InlineKeyboardButton("⭐ Промени качество", callback_data="menu:quality")],
                ]),
            )
        else:
            # File not available — send direct link
            direct = f"https://dyrakarmy.online{result_url}" if result_url and not result_url.startswith("http") else result_url
            await status_msg.edit_text(
                f"✅ *Готово!* Свалянето е завършено.\n\n"
                f"📥 [Изтегли файла]({direct})\n\n"
                f"_Линкът е валиден 1 час._",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("⬇️ Изтегли", url=direct)],
                ]),
            )

    elif data == "cancel":
        await q.edit_message_text("❌ Отказано.")

# ── Bot setup ──────────────────────────────────────────────────────────────────

async def post_init(app: Application):
    await app.bot.set_my_commands([
        BotCommand("start",    "Начало"),
        BotCommand("settings", "Настройки"),
        BotCommand("quality",  "Промени качество"),
        BotCommand("source",   "Избери изтоник"),
        BotCommand("help",     "Помощ"),
    ])
    log.info("DyrakArmy Bot started — @dyrakarmy_bot")

def main():
    app = (
        Application.builder()
        .token(BOT_TOKEN)
        .post_init(post_init)
        .build()
    )
    app.add_handler(CommandHandler("start",    cmd_start))
    app.add_handler(CommandHandler("settings", cmd_settings))
    app.add_handler(CommandHandler("help",     cmd_help))
    app.add_handler(CommandHandler("quality",  cmd_quality))
    app.add_handler(CommandHandler("source",   cmd_source))
    app.add_handler(CallbackQueryHandler(on_callback))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, on_message))

    log.info("Polling started...")
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
