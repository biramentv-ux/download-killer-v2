╔══════════════════════════════════════╗
║   DyrakArmy — Telegram Bot           ║
║   @dyrakarmy_bot                     ║
╚══════════════════════════════════════╝

⚠️  ВАЖНО: Смени токена веднага!
    1. Отиди в @BotFather → /mybots → @dyrakarmy_bot → API Token → Revoke
    2. Сложи новия токен в .env файла

ЛОКАЛНО СТАРТИРАНЕ:
  1. Копирай .env.example → .env
  2. Попълни токена
  3. Изпълни: bash START_BOT.sh  (Linux/Mac)
             START_BOT.bat     (Windows)

RAILWAY DEPLOY (безплатно):
  1. Качи папката в GitHub
  2. Влез в railway.app → New Project → Deploy from GitHub
  3. Добави Environment Variables от .env
  4. Deploy!

КОМАНДИ НА БОТА:
  /start    — Начало
  /settings — Настройки (качество, изтоник)
  /quality  — Смени качество
  /source   — Избери изтоник
  /help     — Помощ
