@echo off
echo Starting DyrakArmy Telegram Bot...
pip install -r requirements.txt --quiet
python dyrakarmy_bot.py
