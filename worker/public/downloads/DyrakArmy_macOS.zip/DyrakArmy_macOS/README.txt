╔══════════════════════════════════════╗
║   DyrakArmy Desktop — macOS          ║
║   Версия 7.0 | dyrakarmy.online      ║
╚══════════════════════════════════════╝

БЪРЗО СТАРТИРАНЕ:
  1. Двойно кликни START.command
     (ако изисква разрешение: System Settings → Privacy → Allow)
  2. При първо стартиране — инсталира нужните библиотеки
  3. Прозорецът ще се отвори с dyrakarmy.online

ЗА .APP (самостоятелен):
  1. Отвори Terminal в тази папка
  2. Изпълни: bash build_app.sh
  3. dist/DyrakArmy.app е готов

НУЖЕН PYTHON: https://python.org/downloads (macOS installer)

ПОДДРЪЖКА: @dyrakarmy_bot в Telegram
