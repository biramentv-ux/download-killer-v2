"""
DyrakArmy Desktop — macOS Portable Launcher
Wraps dyrakarmy.online in a native macOS WebKit window.

Requirements:  pip install pywebview pystray pillow (+ pyobjc on macOS)
Build app:     pyinstaller sounddrop_macos.spec
"""

import sys
import os
import threading
import webbrowser
import json
import urllib.request
import locale
from pathlib import Path

APP_NAME     = "DyrakArmy"
APP_VERSION  = "7.0"
TARGET_URL   = "https://dyrakarmy.online"
WIN_W, WIN_H = 1280, 820
DATA_DIR     = Path.home() / ".dyrakarmy"
ASSETS_DIR   = Path(__file__).parent / "assets"

DATA_DIR.mkdir(parents=True, exist_ok=True)

# ── Detect local backend ──────────────────────────────────────────────────────
def get_base_url() -> str:
    for port in [5000, 8000, 3000]:
        try:
            urllib.request.urlopen(f"http://localhost:{port}/api/health", timeout=1)
            return f"http://localhost:{port}"
        except Exception:
            pass
    return TARGET_URL

def build_app_url(base: str) -> str:
    try:
        lang = "bg" if (locale.getlocale()[0] or "").startswith("bg") else "en"
    except Exception:
        lang = "en"
    return f"{base}/?client=desktop&platform=macos&launcher={APP_VERSION}&lang={lang}"

# ── Desktop Bridge ────────────────────────────────────────────────────────────
class DesktopBridge:
    def get_platform(self):
        return {"platform": "macos", "version": APP_VERSION, "appName": APP_NAME}

    def open_downloads_folder(self):
        folder = Path.home() / "Music" / "DyrakArmy"
        folder.mkdir(parents=True, exist_ok=True)
        os.system(f"open '{folder}'")

    def save_pref(self, key: str, value: str):
        pf = DATA_DIR / "prefs.json"
        try:
            p = json.loads(pf.read_text()) if pf.exists() else {}
            p[key] = value
            pf.write_text(json.dumps(p))
        except Exception:
            pass

    def load_pref(self, key: str, default=""):
        try:
            pf = DATA_DIR / "prefs.json"
            return json.loads(pf.read_text()).get(key, default) if pf.exists() else default
        except Exception:
            return default

# ── macOS menu bar (pystray) ──────────────────────────────────────────────────
_window = None

def create_menu_bar(window):
    try:
        import pystray
        from PIL import Image

        icon_path = ASSETS_DIR / "icon.png"
        img = Image.open(str(icon_path)).resize((22, 22)) if icon_path.exists() else \
              Image.new("RGB", (22, 22), "#00ff88")

        def show(_i, _): window.show() if window else None
        def browser(_i, _): webbrowser.open(TARGET_URL)
        def quit_(_i, _): _i.stop(); window.destroy() if window else None

        icon = pystray.Icon(APP_NAME, img, APP_NAME, pystray.Menu(
            pystray.MenuItem(f"{APP_NAME} v{APP_VERSION}", None, enabled=False),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Show Window",     show, default=True),
            pystray.MenuItem("Open in Browser", browser),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Quit",            quit_),
        ))
        threading.Thread(target=icon.run, daemon=True).start()
    except ImportError:
        pass

# ── Splash ────────────────────────────────────────────────────────────────────
def show_splash():
    gif = ASSETS_DIR / "splash.gif"
    if not gif.exists():
        return
    try:
        import tkinter as tk
        from PIL import ImageTk, Image

        root = tk.Tk()
        root.overrideredirect(True)
        root.configure(bg="#090b0e")
        root.attributes("-topmost", True)

        sw, sh, w, h = root.winfo_screenwidth(), root.winfo_screenheight(), 480, 200
        root.geometry(f"{w}x{h}+{(sw-w)//2}+{(sh-h)//2}")

        frames, gi = [], Image.open(str(gif))
        try:
            while True:
                frames.append(ImageTk.PhotoImage(gi.copy().convert("RGBA")))
                gi.seek(gi.tell() + 1)
        except EOFError:
            pass

        lbl = tk.Label(root, bg="#090b0e")
        lbl.pack(expand=True)
        idx = [0]

        def animate():
            if frames:
                lbl.config(image=frames[idx[0]])
                idx[0] = (idx[0] + 1) % len(frames)
                root.after(42, animate)

        animate()
        root.after(1600, root.destroy)
        root.mainloop()
    except Exception:
        pass

# ── Main ──────────────────────────────────────────────────────────────────────
def main():
    global _window

    splash_t = threading.Thread(target=show_splash, daemon=True)
    splash_t.start()
    splash_t.join(0.1)

    try:
        import webview
    except ImportError:
        webbrowser.open(build_app_url(get_base_url()))
        return

    url     = build_app_url(get_base_url())
    bridge  = DesktopBridge()

    _window = webview.create_window(
        title         = f"{APP_NAME} v{APP_VERSION}",
        url           = url,
        width         = WIN_W,
        height        = WIN_H,
        min_size      = (900, 600),
        resizable     = True,
        confirm_close = False,
        js_api        = bridge,
        # macOS: use native WKWebView with full feature parity
        background_color = "#090b0e",
    )

    def on_loaded():
        create_menu_bar(_window)
        _window.evaluate_js("document.documentElement.classList.add('desktop-app');")

    _window.events.loaded += on_loaded

    splash_t.join()

    webview.start(
        debug        = "--debug" in sys.argv,
        private_mode = False,
        storage_path = str(DATA_DIR / "webview_cache"),
    )

if __name__ == "__main__":
    main()
