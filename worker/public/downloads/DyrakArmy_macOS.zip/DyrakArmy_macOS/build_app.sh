#!/bin/bash
echo "Building DyrakArmy.app ..."
pip3 install pyinstaller pywebview pystray pillow
pyinstaller --onefile --windowed \
  --name=DyrakArmy \
  --add-data "assets:assets" \
  --hidden-import=webview \
  --hidden-import=pystray \
  sounddrop_macos.py
echo "Done! Check dist/DyrakArmy.app"
