#!/bin/bash
# DyrakArmy v7 — macOS Launcher
cd "$(dirname "$0")"

echo "🎵 DyrakArmy v7 — Зарежда се..."

# Check Python3
if ! command -v python3 &>/dev/null; then
    echo "[!] Python3 не е намерен. Инсталирай от https://python.org"
    open "https://dyrakarmy.online"
    exit 1
fi

# Install deps
python3 -m pip install pywebview pystray pillow --quiet 2>/dev/null

# Launch
python3 sounddrop_macos.py
