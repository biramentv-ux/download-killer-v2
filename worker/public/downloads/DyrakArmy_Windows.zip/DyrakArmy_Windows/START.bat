@echo off
title DyrakArmy v7
echo.
echo  ██████╗ ██╗   ██╗██████╗  █████╗ ██╗  ██╗ █████╗ ██████╗ ███╗   ███╗██╗   ██╗
echo  ██╔══██╗╚██╗ ██╔╝██╔══██╗██╔══██╗██║ ██╔╝██╔══██╗██╔══██╗████╗ ████║╚██╗ ██╔╝
echo  ██║  ██║ ╚████╔╝ ██████╔╝███████║█████╔╝ ███████║██████╔╝██╔████╔██║ ╚████╔╝
echo  ██║  ██║  ╚██╔╝  ██╔══██╗██╔══██║██╔═██╗ ██╔══██║██╔══██╗██║╚██╔╝██║  ╚██╔╝
echo  ██████╔╝   ██║   ██║  ██║██║  ██║██║  ██╗██║  ██║██║  ██║██║ ╚═╝ ██║   ██║
echo  ╚═════╝    ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝   ╚═╝
echo.
echo  Зарежда се...

:: Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo  [!] Python не е намерен. Инсталирай от https://python.org
    echo  [!] Натисни Enter за да отвориш браузъра директно...
    pause >nul
    start https://dyrakarmy.online
    exit
)

:: Install deps silently
python -m pip install pywebview pystray pillow --quiet --disable-pip-version-check 2>nul

:: Launch
python sounddrop_windows.py
