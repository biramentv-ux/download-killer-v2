@echo off
echo Building DyrakArmy.exe ...
pip install pyinstaller pywebview pystray pillow
pyinstaller --onefile --windowed --icon=assets/icon.ico --name=DyrakArmy ^
  --add-data "assets;assets" ^
  --hidden-import=webview ^
  --hidden-import=pystray ^
  sounddrop_windows.py
echo Done! Check dist/DyrakArmy.exe
pause
