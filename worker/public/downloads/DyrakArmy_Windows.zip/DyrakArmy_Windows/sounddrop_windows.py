"""
DyrakArmy Desktop — Windows Portable Launcher
Wraps dyrakarmy.online in a native Win32 WebView2 window.

Requirements:  pip install pywebview pystray pillow
Build exe:     pyinstaller sounddrop_windows.spec
"""

import sys
import os
import threading
import webbrowser
import ctypes
import urllib.request
import json
from pathlib import Path

# ── Config ────────────────────────────────────────────────────────────────────
TARGET_URL   = "https://dyrakarmy.online"
APP_NAME     = "DyrakArmy"
APP_VERSION  = "7.0"
WIN_W, WIN_H = 1280, 820
MIN_W, MIN_H = 900, 600
DATA_DIR     = Path.home() / ".dyrakarmy"
ASSETS_DIR   = Path(__file__).parent / "assets"

DATA_DIR.mkdir(parents=True, exist_ok=True)

# ── Windows: set DPI awareness + taskbar icon ────────────────────────────────
if sys.platform == "win32":
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)   # Per-monitor DPI v2
    except Exception:
        pass
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
            f"DyrakArmy.Desktop.{APP_VERSION}"
        )
    except Exception:
        pass

# ── Detect backend (local dev vs production) ──────────────────────────────────
def get_url() -> str:
    """Use local backend if running, else production."""
    for port in [5000, 8000, 3000]:
        try:
            urllib.request.urlopen(f"http://localhost:{port}/api/health", timeout=1)
            url = f"http://localhost:{port}"
            print(f"[DyrakArmy] Using local backend: {url}")
            return url
        except Exception:
            pass
    return TARGET_URL

def build_app_url(base: str, lang: str = "") -> str:
    """Build URL with desktop markers."""
    import locale
    if not lang:
        try:
            loc = locale.getdefaultlocale()[0] or "en"
            lang = "bg" if loc.startswith("bg") else "en"
        except Exception:
            lang = "en"

    params = f"client=desktop&platform=windows&launcher={APP_VERSION}&lang={lang}"
    return f"{base}/?{params}"

# ── System tray icon ──────────────────────────────────────────────────────────
_window = None

def create_tray(window):
    try:
        import pystray
        from PIL import Image

        icon_path = ASSETS_DIR / "icon.png"
        if icon_path.exists():
            image = Image.open(str(icon_path)).resize((64, 64))
        else:
            # Fallback: draw a minimal green icon
            image = Image.new("RGB", (64, 64), "#090b0e")
            from PIL import ImageDraw
            d = ImageDraw.Draw(image)
            d.ellipse([4,4,59,59], outline="#00ff88", width=3)

        def show_window(icon, _):
            if window:
                window.show()

        def open_browser(icon, _):
            webbrowser.open(TARGET_URL)

        def quit_app(icon, _):
            icon.stop()
            if window:
                window.destroy()

        menu = pystray.Menu(
            pystray.MenuItem(f"{APP_NAME} v{APP_VERSION}", None, enabled=False),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Show Window",    show_window, default=True),
            pystray.MenuItem("Open in Browser", open_browser),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Quit", quit_app),
        )

        icon = pystray.Icon(APP_NAME, image, APP_NAME, menu)
        threading.Thread(target=icon.run, daemon=True).start()
        return icon
    except ImportError:
        return None

# ── JavaScript bridge (exposed to web page) ───────────────────────────────────
class DesktopBridge:
    """Methods callable from the web page via window.pywebview.api.*"""

    def minimize(self):
        if _window:
            _window.minimize()

    def maximize(self):
        if _window:
            _window.toggle_fullscreen()

    def get_platform(self):
        return {"platform": "windows", "version": APP_VERSION, "appName": APP_NAME}

    def open_downloads_folder(self):
        folder = str(Path.home() / "Music" / "DyrakArmy")
        Path(folder).mkdir(parents=True, exist_ok=True)
        os.startfile(folder)

    def save_pref(self, key: str, value: str):
        prefs_file = DATA_DIR / "prefs.json"
        try:
            prefs = json.loads(prefs_file.read_text()) if prefs_file.exists() else {}
            prefs[key] = value
            prefs_file.write_text(json.dumps(prefs))
        except Exception:
            pass

    def load_pref(self, key: str, default=""):
        try:
            prefs_file = DATA_DIR / "prefs.json"
            prefs = json.loads(prefs_file.read_text()) if prefs_file.exists() else {}
            return prefs.get(key, default)
        except Exception:
            return default

# ── Splash screen ─────────────────────────────────────────────────────────────
def show_splash():
    """Show a branded splash for ~1.5s before the main window loads."""
    splash_gif = ASSETS_DIR / "splash.gif"
    if not splash_gif.exists():
        return

    try:
        import tkinter as tk
        from PIL import ImageTk, Image

        root = tk.Tk()
        root.overrideredirect(True)
        root.configure(bg="#090b0e")
        root.attributes("-topmost", True)

        sw = root.winfo_screenwidth()
        sh = root.winfo_screenheight()
        w, h = 480, 200
        root.geometry(f"{w}x{h}+{(sw-w)//2}+{(sh-h)//2}")

        frames = []
        gif = Image.open(str(splash_gif))
        try:
            while True:
                frames.append(ImageTk.PhotoImage(gif.copy().convert("RGBA")))
                gif.seek(gif.tell() + 1)
        except EOFError:
            pass

        lbl = tk.Label(root, bg="#090b0e")
        lbl.pack(expand=True)

        idx = [0]
        def animate():
            if frames:
                lbl.config(image=frames[idx[0]])
                idx[0] = (idx[0] + 1) % len(frames)
                root.after(42, animate)

        animate()
        root.after(1600, root.destroy)
        root.mainloop()
    except Exception:
        pass

# ── Main ──────────────────────────────────────────────────────────────────────
def main():
    global _window

    # Splash (non-blocking thread)
    splash_thread = threading.Thread(target=show_splash, daemon=True)
    splash_thread.start()
    splash_thread.join(timeout=0.1)   # Give splash time to appear

    try:
        import webview
    except ImportError:
        # Fallback: just open in browser
        webbrowser.open(build_app_url(get_url()))
        print("Install pywebview for a native window: pip install pywebview")
        return

    base_url = get_url()
    app_url  = build_app_url(base_url)

    bridge = DesktopBridge()

    _window = webview.create_window(
        title         = f"{APP_NAME} v{APP_VERSION}",
        url           = app_url,
        width         = WIN_W,
        height        = WIN_H,
        min_size      = (MIN_W, MIN_H),
        resizable     = True,
        confirm_close = False,
        js_api        = bridge,
    )

    # Wait for splash to finish before starting WebView
    splash_thread.join()

    # Start tray after window is created
    def on_loaded():
        create_tray(_window)
        # Inject desktop CSS tweaks
        _window.evaluate_js("""
            document.documentElement.classList.add('desktop-app');
            document.body.style.userSelect = 'none';
        """)

    _window.events.loaded += on_loaded

    webview.start(
        debug          = "--debug" in sys.argv,
        private_mode   = False,
        storage_path   = str(DATA_DIR / "webview_cache"),
    )

if __name__ == "__main__":
    main()
