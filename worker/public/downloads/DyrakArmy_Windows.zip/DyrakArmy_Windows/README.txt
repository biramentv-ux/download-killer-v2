╔══════════════════════════════════════╗
║   DyrakArmy Desktop — Windows        ║
║   Версия 7.0 | dyrakarmy.online      ║
╚══════════════════════════════════════╝

БЪРЗО СТАРТИРАНЕ:
  1. Двойно кликни START.bat
  2. При първо стартиране — инсталира нужните библиотеки (30сек)
  3. Прозорецът ще се отвори с dyrakarmy.online

ЗА .EXE (standalone, без Python):
  1. Инсталирай Python 3.11+ от https://python.org
  2. Двойно кликни BUILD_EXE.bat
  3. dist/DyrakArmy.exe е готов за разпространение

НУЖЕН PYTHON: https://python.org/downloads
              (отметни "Add to PATH" при инсталация)

ПОДДРЪЖКА: @dyrakarmy_bot в Telegram
